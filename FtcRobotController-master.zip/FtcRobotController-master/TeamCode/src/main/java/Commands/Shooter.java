package Commands;

import com.arcrobotics.ftclib.geometry.Vector2d;
import com.pedropathing.math.Pose;
import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import Subsystems.Vision;
import Utilities.ConfigVariables;
import Utilities.Constants;
import Utilities.RTPAxon;

public class Shooter {
    private final DcMotorEx flywheelMotor1, flywheelMotor2;
    private final DcMotor transfer;
    private final Servo turretHead;
    private final RTPAxon turretNeckMain;
    private final CRServo turretNeckFollower;
    private double distance = 0;
    private double flywheelVel, flywheelPower, transferPower, lastFlywheelPower, lastTransferPower;
    private double neckRelativeAngle, neckTargetAngle, neckPower, headPos;
    private Constants.FlywheelConstants.FlywheelState lastFlywheelState;
    private Constants.TurretConstants.TurretState lastTurretState;
    private Constants.OdometryConstants.FieldSector currentSector = Constants.OdometryConstants.FieldSector.MIDDLE;
    Flywheel flywheel;
    Turret turret;
    Vision vision;
    private Pose lastPos = Constants.OdometryConstants.fieldPos;
    private int offset, lastOffset, lastTarget = 1;
    double shooterToBotCenter = 1.541;
    private Vector2d targetPose;
    private final Vector2d redTarget1 = new Vector2d(58, 53), redTarget2 = new Vector2d(58, 91);
    private final Vector2d blueTarget1 = new Vector2d(84, 53), blueTarget2 = new Vector2d(84, 91);


    public Shooter(HardwareMap hardwareMap) {

        vision = new Vision(hardwareMap);

        turretNeckMain = new RTPAxon(hardwareMap.get(CRServo.class, Constants.TurretConstants.turretNeckAxon), hardwareMap.get(AnalogInput.class, Constants.TurretConstants.turretNeckEncoder));
        turretNeckMain.setPIDF(ConfigVariables.neckp, ConfigVariables.necki, ConfigVariables.neckd, ConfigVariables.neckf);
        turretNeckFollower = hardwareMap.get(CRServo.class, Constants.TurretConstants.turretNeckCR);
        turretHead = hardwareMap.get(Servo.class, Constants.FlywheelConstants.turretHeadServo);

        flywheelMotor1 = hardwareMap.get(DcMotorEx.class, Constants.FlywheelConstants.flywheel2);
        flywheelMotor2 = hardwareMap.get(DcMotorEx.class, Constants.FlywheelConstants.flywheel2);
        transfer = hardwareMap.get(DcMotor.class, Constants.FlywheelConstants.transfer);

        flywheelMotor1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheelMotor1.setDirection(DcMotorSimple.Direction.FORWARD);
        flywheelMotor1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        flywheelMotor2.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheelMotor2.setDirection(DcMotorSimple.Direction.REVERSE);
        flywheelMotor2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.FLOAT);

        turretHead.setDirection(Servo.Direction.FORWARD);

        if (Constants.onRed) targetPose = redTarget1;
        else targetPose = blueTarget1;

        flywheel = new Flywheel();
        turret = new Turret(hardwareMap);

        aim(Constants.FlywheelConstants.FlywheelState.SCORE, Constants.TurretConstants.TurretState.AUTO, 0, 0);
    }

    public void aim(Constants.FlywheelConstants.FlywheelState flywheelState, Constants.TurretConstants.TurretState turretState, double manualX, double manualY) {
        vision.updateAprilTags();
        updateVariables();
        updateTarget();

        boolean stateSwapped = flywheelState != lastFlywheelState || turretState != lastTurretState;

        lastFlywheelState = flywheelState;
        lastTurretState = turretState;
        double heading = Constants.OdometryConstants.fieldPos.heading();

        if (turretState == Constants.TurretConstants.TurretState.MANUAL)
            neckTargetAngle = turret.calculateTarget(manualX, manualY, heading, neckRelativeAngle, offset);
        if (turretState == Constants.TurretConstants.TurretState.LOCKED) neckTargetAngle = 0;

        if (Constants.OdometryConstants.fieldPos.distance(lastPos) < 1 || offset != lastOffset || stateSwapped) {

            if (Constants.OdometryConstants.fieldPos.x() < targetPose.getX() - 5 && currentSector != Constants.OdometryConstants.FieldSector.LEFT){
                currentSector = Constants.OdometryConstants.FieldSector.LEFT;;
                targetPose = new Vector2d(targetPose.getX() + 5, targetPose.getY());
            } else if (Constants.OdometryConstants.fieldPos.x() > targetPose.getX() + 5 && currentSector != Constants.OdometryConstants.FieldSector.RIGHT){
                currentSector = Constants.OdometryConstants.FieldSector.RIGHT;
                targetPose = new Vector2d(targetPose.getX() - 5, targetPose.getY());
            } else currentSector = Constants.OdometryConstants.FieldSector.MIDDLE;

            double xChange = Constants.OdometryConstants.fieldPos.x() - targetPose.getX();
            double yChange = Constants.OdometryConstants.fieldPos.y() - targetPose.getY();
            distance = Math.sqrt(Math.pow(xChange, 2) + Math.pow(yChange, 2));

            /*
            double time = Math.sqrt(Math.pow((distance - 20) / 39.37, 2) / 9.8) * 2; //TODO: FIND A BETTER WAY TO GET TIME
            xChange += Constants.OdometryConstants.fieldVels[0] * time;
            yChange += Constants.OdometryConstants.fieldVels[1] * time;
            heading += Constants.OdometryConstants.fieldVels[2] * time;
             */

            distance = Math.sqrt(Math.pow(xChange, 2) + Math.pow(yChange, 2));

            headPos = flywheel.getHeadPositions(flywheelState, distance);

            if (turretState == Constants.TurretConstants.TurretState.AUTO)
                neckTargetAngle = turret.calculateTarget(xChange, yChange, heading, neckRelativeAngle, offset);

            lastOffset = offset;
            lastPos = Constants.OdometryConstants.fieldPos;
        }

        flywheelPower = flywheel.getFlywheelPower(flywheelState, distance, flywheelVel);
    }

    public Pose getVisionPos() {
        return vision.getPose(turret.getNeckHeading());
    }

    public void manualOffset(boolean leftTrigger, boolean rightTrigger) {
        if (leftTrigger) offset -= 4;
        if (rightTrigger) offset += 4;
    }

    public void updateTarget() {
        if (vision.tiltedSide() == lastTarget) return;
        if (lastTarget == 1) {
            if (Constants.onRed) targetPose = redTarget2;
            else targetPose = blueTarget2;
            lastTarget = 2;
        } else {
            if (Constants.onRed) targetPose = redTarget1;
            else targetPose = blueTarget1;
            lastTarget = 1;
        }
    }

    private void updateVariables() {
        neckRelativeAngle = turretNeckMain.getCurrentDegrees();
        flywheelVel = flywheelMotor1.getVelocity();
    }

    public void updateFlywheelHardware() {
        if (flywheelPower == lastFlywheelPower) return;
        flywheelMotor1.setPower(flywheelPower);
        flywheelMotor2.setPower(flywheelPower);
        turretHead.setPosition(headPos);
    }

    public void updateTransfer() {
        if (transferPower == lastTransferPower) return;
        transfer.setPower(transferPower);
    }


    public void updateTurretHardware() {
        turretNeckMain.setTargetDegrees(neckTargetAngle);
        turretNeckFollower.setPower(turretNeckMain.getPower());
    }

    public void chill() {
        flywheelMotor1.setPower(0);
        flywheelMotor2.setPower(0);
    }

}