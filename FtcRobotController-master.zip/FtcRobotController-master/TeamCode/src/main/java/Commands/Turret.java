package Commands;

import com.qualcomm.robotcore.hardware.HardwareMap;

import Subsystems.PIDFController;
import Utilities.ConfigVariables;
import Utilities.Constants;

public class Turret {
    private double neckHeading;
    final double rotationMax = Constants.TurretConstants.turretNeckGearRatio * 360,  radianMax = 2 * Math.PI;
    final double upperLimit = rotationMax/2, lowerLimit = -rotationMax/2;

    public Turret(HardwareMap hardwareMap) {
    }

    public double calculateTarget(double xChange, double yChange, double botHeading, double neckCurrentAngle, int offset) {
        if (botHeading < 0) {
            botHeading += radianMax;
        }

        neckHeading = (botHeading - ((neckCurrentAngle - offset) / rotationMax * radianMax)) % radianMax;

        double headingTarget = Math.atan2(xChange, yChange);
        double targetNeckAngle = (int) (neckCurrentAngle + wrapHeading(headingTarget + neckHeading));
        if (targetNeckAngle > upperLimit) targetNeckAngle -= (int) rotationMax;
        if (targetNeckAngle < lowerLimit) targetNeckAngle += (int) rotationMax;
        return targetNeckAngle;

    }

    public double getNeckHeading(){
        return neckHeading;
    }

    private double wrapHeading(double angleToTurnDeg) {
        if (angleToTurnDeg < 0) {
            angleToTurnDeg += radianMax;
        }
        return angleToTurnDeg * Constants.GoBildaMotorMax * Constants.TurretConstants.turretNeckGearRatio / radianMax;
    }
}
