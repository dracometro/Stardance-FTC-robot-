package Utilities;

import com.acmerobotics.dashboard.config.Config;

@Config
public final class ConfigVariables {
    public static int velocity = 2800;
    public static double neckp = 0.0033;
    public static double necki = 0.0001;
    public static double neckd = 0;
    public static double neckf = 0;

    public static double flywheelP = 0;
    public static double flywheelI = 0;
    public static double flywheelD = 0;
    public static double flywheelF = 0;
}
