package Utilities;

import com.qualcomm.robotcore.hardware.AnalogInput;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

/**
 * Run-to-position wrapper for an Axon continuous-rotation servo using its
 * analog absolute encoder.
 *
 * Adds over the basic version:
 *  - Multi-turn position tracking (positions beyond 0-360 deg, positive or negative)
 *  - Time-normalized PIDF control with anti-windup and a tolerance deadband
 *  - Selectable MULTI_TURN (unwrapped) or CONTINUOUS (shortest-path) targeting
 *  - Optional custom feedforward (e.g. gravity compensation on an arm)
 *
 * IMPORTANT: update() must be called faster than the servo can travel 180 deg
 * between calls, or the wrap detection will miscount a revolution. At full
 * speed an Axon is roughly 1 rev / 0.2 s, so anything under ~50 ms per loop is
 * comfortable. Don't skip update() while the servo is moving.
 */
public class RTPAxon {

    public enum Mode {
        /** Target is an absolute unwrapped angle; the servo can spin past 360 deg. */
        MULTI_TURN,
        /** Target is 0-360 deg; the controller takes the shortest path to it. */
        CONTINUOUS
    }

    /** Optional feedforward hook, e.g. {@code (pos, tgt) -> kG * Math.cos(Math.toRadians(pos))}. */
    public interface Feedforward {
        double compute(double currentDegrees, double targetDegrees);
    }

    private final CRServo servo;
    private final AnalogInput encoder;
    private final ElapsedTime timer = new ElapsedTime();

    // --- PIDF coefficients ---
    private double Kp = 0.015;
    private double Ki = 0.0;
    private double Kd = 0.001;
    /** Static feedforward: constant power applied in the direction of travel to break stiction. */
    private double Kf = 0.0;
    private Feedforward feedforward = null;

    // --- Encoder / position state ---
    /** Full-scale voltage of the encoder output. Measure yours; it is often ~3.28V, not exactly 3.3V. */
    private double maxVoltage = 3.3;
    private double lastRawDegrees;
    private int rotations = 0;
    private double offsetDegrees = 0.0;
    private boolean reversed = false;

    // --- Controller state ---
    private Mode mode = Mode.MULTI_TURN;
    private double targetDegrees = 0.0;
    private double integralSum = 0.0;
    private double lastError = 0.0;
    private double power = 0.0;
    private double maxPower = 1.0;
    private double toleranceDegrees = 1.5;
    private double maxIntegral = 50.0;   // clamp on the integral accumulator (deg*s)
    private boolean hasRun = false;

    public RTPAxon(CRServo servo, AnalogInput encoder) {
        this.servo = servo;
        this.encoder = encoder;
        this.lastRawDegrees = readRawDegrees();
        this.targetDegrees = this.lastRawDegrees;
        timer.reset();
    }

    // ------------------------------------------------------------------
    // Encoder
    // ------------------------------------------------------------------

    /** Raw absolute reading of the encoder, 0-360 deg, with no turn counting. */
    public double readRawDegrees() {
        double deg = (encoder.getVoltage() / maxVoltage) * 360.0;
        deg = Range.clip(deg, 0.0, 360.0);
        return reversed ? (360.0 - deg) % 360.0 : deg;
    }

    /**
     * Accumulated position in degrees, unbounded: 725 deg means two full turns plus 5 deg
     * from the zero point, and negative values are valid. Call update() (or this method)
     * frequently enough to catch every wrap.
     */
    public double getCurrentDegrees() {
        double raw = readRawDegrees();
        double delta = raw - lastRawDegrees;

        // A jump larger than half a revolution between samples means the encoder wrapped.
        if (delta > 180.0) rotations--;
        else if (delta < -180.0) rotations++;

        lastRawDegrees = raw;
        return (rotations * 360.0) + raw - offsetDegrees;
    }

    /** Current position folded into 0-360 deg. */
    public double getWrappedDegrees() {
        double d = getCurrentDegrees() % 360.0;
        return d < 0 ? d + 360.0 : d;
    }

    /** Treat the current physical position as zero. */
    public void resetPosition() {
        lastRawDegrees = readRawDegrees();
        rotations = 0;
        offsetDegrees = lastRawDegrees;
        resetController();
    }

    /** Full-scale encoder voltage; measure it by turning the servo slowly and watching the peak. */
    public void setMaxVoltage(double volts) {
        this.maxVoltage = volts;
    }

    /** Flip this if the encoder counts up while the servo's positive power drives it down. */
    public void setEncoderReversed(boolean reversed) {
        this.reversed = reversed;
        this.lastRawDegrees = readRawDegrees();
    }

    // ------------------------------------------------------------------
    // Control
    // ------------------------------------------------------------------

    public void setTargetDegrees(double degrees) {
        if (mode == Mode.CONTINUOUS) {
            degrees = degrees % 360.0;
            if (degrees < 0) degrees += 360.0;
        }
        if (degrees != this.targetDegrees) {
            this.targetDegrees = degrees;
            this.integralSum = 0.0;   // don't carry windup from the old setpoint
        }
    }

    public void addTargetDegrees(double delta) {
        setTargetDegrees(targetDegrees + delta);
    }

    public double getTargetDegrees() {
        return targetDegrees;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
        resetController();
    }

    /** Signed error in degrees, already wrapped if the mode calls for it. */
    public double getError() {
        double error = targetDegrees - (mode == Mode.CONTINUOUS ? getWrappedDegrees() : getCurrentDegrees());
        if (mode == Mode.CONTINUOUS) {
            if (error > 180.0) error -= 360.0;
            else if (error < -180.0) error += 360.0;
        }
        return error;
    }

    public boolean isAtTarget() {
        return Math.abs(getError()) <= toleranceDegrees;
    }

    /** Call this every loop iteration. Returns the power that was commanded. */
    public double update() {
        double error = getError();

        double dt = timer.seconds();
        timer.reset();
        // Guard against a zero/huge dt on the first loop or after a long stall.
        if (!hasRun || dt <= 0.0 || dt > 0.25) {
            dt = 0.02;
            lastError = error;
            hasRun = true;
        }

        if (Math.abs(error) <= toleranceDegrees) {
            integralSum = 0.0;
            lastError = error;
            setPower(0.0);
            return 0.0;
        }

        // Integral, clamped and dumped whenever the error changes sign.
        if (Math.signum(error) != Math.signum(lastError)) integralSum = 0.0;
        integralSum += error * dt;
        integralSum = Range.clip(integralSum, -maxIntegral, maxIntegral);

        double derivative = (error - lastError) / dt;

        double ff = Kf * Math.signum(error);
        if (feedforward != null) ff += feedforward.compute(getCurrentDegrees(), targetDegrees);

        double newPower = (Kp * error) + (Ki * integralSum) + (Kd * derivative) + ff;
        newPower = Range.clip(newPower, -maxPower, maxPower);

        lastError = error;
        setPower(newPower);
        return newPower;
    }

    /** Stop the servo and clear the accumulated controller state. */
    public void resetController() {
        integralSum = 0.0;
        lastError = 0.0;
        hasRun = false;
        timer.reset();
        setPower(0.0);
    }

    // ------------------------------------------------------------------
    // Power / tuning
    // ------------------------------------------------------------------

    public double getPower() {
        return power;
    }

    public void setPower(double newPower) {
        newPower = Range.clip(newPower, -1.0, 1.0);
        if (Math.abs(newPower - power) < 1e-4) return;   // avoid spamming the servo controller
        power = newPower;
        servo.setPower(power);
    }

    public void setPIDF(double p, double i, double d, double f) {
        this.Kp = p;
        this.Ki = i;
        this.Kd = d;
        this.Kf = f;
    }

    public void setPID(double p, double i, double d) {
        setPIDF(p, i, d, this.Kf);
    }

    public void setFeedforward(Feedforward ff) {
        this.feedforward = ff;
    }

    /** Cap on output magnitude, 0-1. Useful for slowing a heavy mechanism. */
    public void setMaxPower(double maxPower) {
        this.maxPower = Range.clip(Math.abs(maxPower), 0.0, 1.0);
    }

    public void setTolerance(double degrees) {
        this.toleranceDegrees = Math.abs(degrees);
    }

    public void setMaxIntegral(double maxIntegral) {
        this.maxIntegral = Math.abs(maxIntegral);
    }

    /** One-line dump for telemetry. */
    public String getTelemetry() {
        return String.format("pos=%.1f tgt=%.1f err=%.1f pwr=%.2f turns=%d",
                getCurrentDegrees(), targetDegrees, getError(), power, rotations);
    }
}