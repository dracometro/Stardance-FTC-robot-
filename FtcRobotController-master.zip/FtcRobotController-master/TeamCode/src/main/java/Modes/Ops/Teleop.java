package Modes.Ops;


import com.acmerobotics.dashboard.FtcDashboard;
import com.qualcomm.robotcore.hardware.Gamepad;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;


import org.firstinspires.ftc.robotcore.external.Telemetry;

import Commands.Intake;
import Commands.MecanumDrive;
import Commands.StraightShooter;
import Utilities.Constants;

public class Teleop {
    //Sample teleop, shows how this all should be structured
    Telemetry telemetry = FtcDashboard.getInstance().getTelemetry();
    MecanumDrive mecanum;
    ElapsedTime controlLoopTimer;
    //List<LynxModule> allHubs;
    Gamepad lastDriver = new Gamepad(), lastOperator = new Gamepad();
    StraightShooter shooter;
    Intake intake;
    Constants.TurretConstants.TurretState turretState = Constants.TurretConstants.TurretState.AUTO;
    Constants.FlywheelConstants.FlywheelState flywheelState = Constants.FlywheelConstants.FlywheelState.SCORE;

    public void init(HardwareMap hardwareMap, boolean onRed) {
        Constants.onRed = onRed;
        mecanum = new MecanumDrive(hardwareMap);
        controlLoopTimer = new ElapsedTime();
        //shooter = new Shooter(hardwareMap);
        shooter = new StraightShooter(hardwareMap);
        intake = new Intake(hardwareMap);
        /*
        allHubs = hardwareMap.getAll(LynxModule.class);
        for (LynxModule module : allHubs) {
            module.setBulkCachingMode(LynxModule.BulkCachingMode.AUTO);
        }
         */
    }

    public void run(Gamepad driver, Gamepad operator) {

        turretState = Constants.TurretConstants.TurretState.AUTO;
        if (operator.a) {
            flywheelState = Constants.FlywheelConstants.FlywheelState.PASS;
        } else if (operator.left_trigger > 0.4 && operator.right_trigger > 0.4) {
            flywheelState = Constants.FlywheelConstants.FlywheelState.FLOWER;
            turretState = Constants.TurretConstants.TurretState.LOCKED;
        }

        //if (Math.abs(operator.left_stick_y) > 0.4 || Math.abs(operator.left_stick_x) > 0.4) shooter.aim(flywheelState, turretState, operator.left_stick_x, operator.left_stick_y);
        //else shooter.aim(flywheelState, turretState, 0, 0);
        shooter.aim(flywheelState);

        mecanum.drive(-driver.left_stick_y, driver.left_stick_x, -driver.right_stick_x);

        shooter.updateFlywheelHardware();

        if (driver.dpadDownWasReleased()) {
            mecanum.resetIMU();
        }

        shooter.transfer(driver.left_trigger > 0.4);
        intake.intake(driver.right_trigger > 0.4, driver.a);

        lastOperator.copy(operator);
        lastDriver.copy(driver);
        telemetry();
    }

    public void telemetry() {
        telemetry.addData("Driver inputs: ", lastDriver);
        //telemetry.addData("Operator inputs: ", operator);
        telemetry.addData("Control loop time (ms): ", controlLoopTimer.time() * 1e3);
        mecanum.telemetry(telemetry);
        intake.telemetry(telemetry);
        shooter.telemetry(telemetry);
        controlLoopTimer.reset();
        telemetry.update();
    }

}
